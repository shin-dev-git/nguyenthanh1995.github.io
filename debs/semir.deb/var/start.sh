#!/bin/sh

# Chào mừng
echo "----------------------------------------"
echo "Phần I. Chào mừng"
printf "Chào mừng đến với \033[34mCydiaSlayer\033[0m cho \033[35miOS 10.3.x\033[0m của \033[33mDevNTNghia!\033[0m\n"
echo "Cảm ơn bạn đã tin tưởng dùng sản phẩm của mình!"
read -p "Nhấn RETURN để tiếp tục."

# Các thay đổi
clear
echo "Phần II. Các thay đổi"
printf "\033[33m--- Các thay đổi có trong bản 1.2 ---\033[0m\n"
echo "- Chính thức đổi tên từ Semi-Restore thành CydiaSlayer!
- Thay đổi toàn bộ cấu trúc lệnh để phù hợp với 32bit và doubleH3lix!
- Hỗ trợ hoàn toàn doubleH3lix!
- Hỗ trợ hoàn toàn các máy chạy 32bit dùng H3lix!
- Hỗ trợ làm sạch /var/mobile/Documents.
- Thêm lệnh kiểm tra License.
- Thêm lệnh tắt ứng dụng chạy ngầm có thể gây lỗi trong quá trình xoá Jailbreak.
- Thêm DEPICTION cho Tweak để người dùng có thể xem thêm thông tin về Tweak.
- Tiếp tục giảm thiểu những lệnh bị thừa và trùng.
- Xóa thêm 1 số file lib còn động lại.
- Viết lại nội dung lưu ý."
read -p "Nhấn RETURN để tiếp tục."

# Lưu ý
clear
echo "Phần III. Lưu ý"
printf "\033[31m-- Các lưu ý cần phải đọc kĩ trước khi sử dụng:\033[0m\n"
printf "\033[33m- Bạn phải xoá tất cả các Tweak có trên màn hình chính trước khi tiến hành xóa Jailbreak.\033[0m\n"
printf "\033[33m- Trong lúc đang xoá Jailbreak, bạn không được làm bất cứ thứ gì như gọi điện, nhắn tin,...\033[0m\n"
printf "\033[33m- Hãy để Tự động khóa về 0s để không bị ảnh hưởng đến việc xóa Jailbreak.\033[0m\n"
printf "\033[33m- Khi lệnh chạy xong, máy sẽ tự khởi động lại và trở về trạng thái như chưa từng Jailbreak.\033[0m\n"
printf "\033[31m-- Lưu ý ĐẶC BIỆT:\033[0m\n"
printf "\033[33m- Chỉ nên cài từ nguồn\033[0m \033[32mdevntnghia.github.io\033[0m \033[36mđể được update thường xuyên nhất.\033[0m\n"
printf "\033[33m- Hãy là 1 con người văn minh, đừng cướp đi sức lao động của người khác và quyền tác giả của họ.\033[0m\n"

# Lựa chọn
echo ""
echo -n "----------------------------------------
Bạn có muốn tiếp tục không? Hãy chọn 1 trong 2:
1. Có
2. Không
> "

read choose_opt

if [ -z ${choose_opt} ] || [ ${choose_opt} != "1" ]; then
    clear
    printf "\033[32mĐã thoát.\033[0m\n"
    exit
fi

# Check binary digit
CHECKBIT=$(arch)

# Confirm bnary digit
if [ "$CHECKBIT" == "arm64" ]; then
	echo "--------------------"
	echo "Xác nhận máy chạy 64bit!"
	sleep 1
	echo "Đang chuẩn bị lệnh..."
	sleep 2
	sudo sh /var/64bit.sh
elif [ "$CHECKBIT" == "arm" ] || [ "$CHECKBIT" == "armv7" ]; then
	echo "--------------------"
	echo "Xác nhận máy chạy 32bit!"
	sleep 1
	echo "Đang chuẩn bị lệnh..."
	sleep 2
	sudo sh /var/32bit.sh
fi
