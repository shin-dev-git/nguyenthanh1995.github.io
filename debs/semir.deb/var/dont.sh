#!/bin/sh

echo "CydiaSlayer đã bị LEAK sang source khác.
DevNTNghia không cho phép điều này.
Mong bạn hãy cài từ source chính!
Sau thông báo, bạn hãy vào Cydia để thêm source chính và tải lại.

Source chính:
devntnghia.github.io"
sleep 3
rm -f /var/32bit.sh
rm -f /var/64bit.sh
rm -f /var/start.sh
rm -f /var/finish.sh
rm -f /var/dont.sh
cd /usr/bin
rm -f ubjb
touch unjb
echo "CydiaSlayer đã bị tải từ Source khác không phải từ Source chính!
Mong bạn hãy xóa bản này và tải lại từ Source chính để được hỗ trợ hoàn thiện nhất từ tác giả!

Source chính:
devntnghia.github.io" >> unjb
exit