echo "ĐÂY CHỈ LÀ FILE THAY THẾ CHO FILE start.sh đã bị hỏng. Lúc mình sẽ fix lại. Mong các bạn thông cảm!"

CHECKBIT=$(arch)

if [ "$CHECKBIT" == "arm64" ]; then
echo "64bit"
sudo sh /var/64bit.sh
elif [ "$CHECKBIT" == "arm" ] || [ "$CHECKBIT" == "armv7" ]; then
echo "32bit"
sudo sh /var/32bit.sh
fi