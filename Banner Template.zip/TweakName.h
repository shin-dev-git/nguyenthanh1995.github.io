//Import everything inside PSViewController
#import <Preferences/PSViewController.h>
#import <Preferences/PSListController.h>
#import <Preferences/PSListItemsController.h>
#import <Preferences/PSSpecifier.h>
#import <Preferences/PSSliderTableCell.h>
#import <Preferences/PSSwitchTableCell.h>
#import <Preferences/PSTableCell.h>

@interface TweakLogoCell : PSTableCell

@property (nonatomic, strong) UIImageView *logoView;

@end
