#import "ahihi.h"

@implementation TweakLogoCell

- (id)initWithSpecifier:(PSSpecifier *)specifier {
	self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"LogoCell" specifier:specifier];
	
	if (self) {
		self.backgroundColor = UIColor.clearColor;
		
		NSString *path = [NSString stringWithFormat:@"/Library/PreferenceBundles/TweakName.bundle/Logo.png"];
		UIImage *logo = [UIImage imageWithContentsOfFile:path];
		UIImageView *logoView = [[UIImageView alloc] initWithImage:logo];
		logoView.center = self.contentView.center;
		logoView.contentMode = UIViewContentModeCenter;
		logoView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
		
		[self.contentView addSubview:logoView];
	}
	return self;
}

- (CGFloat)preferredHeightForWidth:(CGFloat)height {
	return 100.0f;
}

@end
